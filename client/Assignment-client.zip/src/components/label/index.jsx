import Label from "./Label"

export { Label }