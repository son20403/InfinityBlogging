import Badge from "./Badge";
import Title from "./Title";
import Heading from "./Heading";
export { Title, Badge, Heading }