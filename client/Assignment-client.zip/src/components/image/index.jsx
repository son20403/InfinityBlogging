import ImagePost from "./ImagePost";

export { ImagePost }